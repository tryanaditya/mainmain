# THIS FILE IS GENERATED FROM THE SETUP.PY. DO NOT EDIT.

short_version='0.2.5'
version=short_version
dev=False
if dev:
    version += '.dev'
